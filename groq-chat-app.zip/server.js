require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const app = express();
const path = require('path');

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.post('/api/chat', async (req, res) => {
  const userMessage = req.body.message;
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + process.env.GROQ_API_KEY
      },
      body: JSON.stringify({
        model: "llama3-8b-8192",
        messages: [
          { role: "system", content: "You are a helpful assistant. Use markdown for code formatting." },
          { role: "user", content: userMessage }
        ]
      })
    });

    const data = await response.json();
    res.json({ reply: data.choices?.[0]?.message?.content || "❌ No reply from AI" });
  } catch (err) {
    res.status(500).json({ reply: "❌ Error: " + err.message });
  }
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
